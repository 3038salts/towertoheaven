# Tower To Heaven
# CMU 15-112 Summer 2023 Term Project

In this game, you start out as a cute cat in a forest. One day, you encounter a
tower and open the door. As you ascend the tower, you will fight ghosts and
avoid spinning blades. You have the mytical abiity to shoot bullets. When you
reach the top of the tower, you'll be in heaven!

# How to run the code?
Open up the folder "TP3" and run main.py.

# Any external modules?
Nope.

# Any shortcuts?
I do not endorse cheating.