class Obstacles:
    def __init__(self):
        self.x = 0
        self.y = 0

class Pit(Obstacles):
    def __init__(self):
        super().__init__()

class SpinningBlades(Obstacles):
    def __intit__(self):
        super().__init__()