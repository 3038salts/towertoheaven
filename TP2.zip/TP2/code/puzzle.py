class Puzzle:
    def __init__(self):
        self.rows = 5
        self.cols = 5