from cmu_graphics import *
import random

def onAppStart(app):
    pass

def redrawAll(app):
    pass

def main():
    runApp()

main()